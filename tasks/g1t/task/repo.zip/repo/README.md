Flag is... Somewhere.
